<?php
$ip_esp = "http://192.168.0.110/ligar_buzzer"; // IP do ESP
file_get_contents($ip_esp); // Executa o comando
echo "Comando enviado ao ESP32!";
?>
